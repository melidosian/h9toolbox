# 杰理工具链 Linux 版本使用说明

工具链解压后，有如下几个目录以及文件
```
common/
pi32/
pi32v2/
q32s/
```

不同芯片的工具版本在`pi32/` `pi32v2/` `q32s/` 目录下，需要对应修改　`Makefile`　中的 `CC` 等变量

## 注意事项

1. 在链接的过程中，可能会打开大量的文件。注意先通过`ulimit -n 8192`等类似的命令将文件限额改大。否则可能会出现类似`error adding symbols: File format not recognized`的错误
